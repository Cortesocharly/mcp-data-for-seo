import { BaseTool, DataForSEOFullResponse } from '../../../base.tool.js';
import { DataForSEOClient } from '../../../../client/dataforseo.client.js';
import { ZodRawShape } from 'zod';

export class AiOptimizationLlmMentionsLocationsAndLanguagesListTool extends BaseTool {

    constructor(dataForSEOClient: DataForSEOClient) {
        super(dataForSEOClient);
    }

    getTitle(): string {
        return 'AI Optimization LLM Mentions Locations and Languages';
    }

    protected supportOnlyFullResponse(): boolean {
        return true;
    }

    getName(): string {
        return "ai_opt_llm_ment_loc_and_lang";
    }

    getDescription(): string {
        return "Utility tool for 'AI Optimization LLM Mentions Locations and Languages' (ai_opt_llm_ment_loc_and_lang) to get list of available locations and languages";
    }

    getParams(): ZodRawShape {
        return {};
    }

    async handle(params: any): Promise<any> {
        try {

            const response = await this.dataForSEOClient.makeRequest(`/v3/ai_optimization/llm_mentions/locations_and_languages`, 'GET', null) as any;
            return this.formatResponse(response['items']);
        } catch (error) {
            return this.formatErrorResponse(error);
        }
    }
}